//
//  Queue.m
//  Mobile Clinic
//
//  Created by Michael Montaque on 4/21/13.
//  Copyright (c) 2013 Steven Berlanga. All rights reserved.
//
#import "Queue.h"

@implementation Queue

@dynamic data;
@dynamic title;
@dynamic pId;

@end