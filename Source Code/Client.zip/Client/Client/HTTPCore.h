//
//  HTTPCore.h
//  MobileClinic
//
//  Created by Michael Montaque on 1/31/13.
//  Copyright (c) 2013 Florida International University. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HTTPCore : NSObject
- (void)grabURLInBackground:(id)sender;
@end
