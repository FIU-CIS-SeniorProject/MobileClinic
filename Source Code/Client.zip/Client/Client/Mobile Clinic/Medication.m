//
//  Medication.m
//  Mobile Clinic
//
//  Created by Rigo Hernandez on 2/20/13.
//  Copyright (c) 2013 Steven Berlanga. All rights reserved.
//

#import "Medication.h"


@implementation Medication

@dynamic dosage;
@dynamic expiration;
@dynamic medId;
@dynamic medName;
@dynamic numContainers;
@dynamic tabletsContainer;

@end
