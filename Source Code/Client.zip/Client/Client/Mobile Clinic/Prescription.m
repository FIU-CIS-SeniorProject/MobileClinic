//
//  Prescription.m
//  Mobile Clinic
//
//  Created by Michael Montaque on 2/25/13.
//  Copyright (c) 2013 Steven Berlanga. All rights reserved.
//

#import "Prescription.h"


@implementation Prescription

@dynamic instructions;
@dynamic medicationId;
@dynamic prescribedTime;
@dynamic tabletPerDay;
@dynamic timeOfDay;
@dynamic visitId;
@dynamic prescriptionId;

@end
