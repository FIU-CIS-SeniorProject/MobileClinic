//
//  CancelDelegate.h
//  Mobile Clinic
//
//  Created by Michael Montaque on 5/7/13.
//  Copyright (c) 2013 Steven Berlanga. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol CancelDelegate <NSObject>
-(void)cancel;
@end
