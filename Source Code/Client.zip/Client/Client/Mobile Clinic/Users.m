//
//  Users.m
//  Mobile Clinic
//
//  Created by Michael Montaque on 2/26/13.
//  Copyright (c) 2013 Steven Berlanga. All rights reserved.
//

#import "Users.h"
#import "Patients.h"


@implementation Users

@dynamic email;
@dynamic firstName;
@dynamic lastName;
@dynamic password;
@dynamic status;
@dynamic userName;
@dynamic userType;
@dynamic patient;

@end
