//
//  Patients.m
//  Mobile Clinic
//
//  Created by Michael Montaque on 2/27/13.
//  Copyright (c) 2013 Steven Berlanga. All rights reserved.
//

#import "Patients.h"
#import "Visitation.h"


@implementation Patients

@dynamic age;
@dynamic familyName;
@dynamic firstName;
@dynamic patientId;
@dynamic photo;
@dynamic sex;
@dynamic status;
@dynamic villageName;
@dynamic isLockedBy;
@dynamic visit;
@dynamic label;

@end
