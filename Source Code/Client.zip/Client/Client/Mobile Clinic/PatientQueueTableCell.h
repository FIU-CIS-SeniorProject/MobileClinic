//
//  PatientQueueTableCell.h
//  Mobile Clinic
//
//  Created by sebastian a zanlongo on 3/7/13.
//  Copyright (c) 2013 Steven Berlanga. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PatientQueueViewController.h"

@interface PatientQueueTableCell : UITableViewCell

@property (nonatomic, strong) PatientQueueViewController * viewController;

@end
