//
//  TriageViewControllerTest.m
//  Mobile Clinic
//
//  Created by Rigo Hernandez on 3/27/13.
//  Copyright (c) 2013 Steven Berlanga. All rights reserved.
//

#import <GHUnitIOS/GHUnit.h>
#import "TriageViewController.h"
#import "PatientObject.h"

@interface TriageViewControllerTest: GHAsyncTestCase

@end

PatientObject *patientData;

@implementation TriageViewControllerTest

- (void)setUpClass {
    // Run at beginning of all tests in the class
}

- (void)tearDownClass {
    // Run at end of all tests in the class
}

- (void)setUp {
    // Run before each test method
}

- (void)tearDown {
    // Run after each test method
}

@end
