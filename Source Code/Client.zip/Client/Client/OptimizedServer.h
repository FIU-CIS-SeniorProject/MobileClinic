//
//  OptimizedServer.h
//  Mobile Clinic
//
//  Created by Michael Montaque on 5/8/13.
//  Copyright (c) 2013 Steven Berlanga. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OptimizedServer : NSObject

@end
