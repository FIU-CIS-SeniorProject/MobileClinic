//
//  CloudManager.m
//  Mobile Clinic
//
//  Created by James Mendez on 11/28/13.
//  Copyright (c) 2013 Florida International University. All rights reserved.
//
#import "CloudManager.h"

@implementation CloudManager

@dynamic name;
@dynamic cloudURL;
@dynamic isActive;
@dynamic isDirty;
@dynamic lastPullTime;

@end
