//
//  Face.m
//  Mobile Clinic
//
//  Created by Humberto Suarez on 11/10/13.
//  Copyright (c) 2013 Florida International University. All rights reserved.
//

#import "Face.h"

@implementation Face
@dynamic familyName;
@dynamic firstName;
@dynamic patientId;
@dynamic photo;
@dynamic isLockedBy;
@dynamic label;

@end
